package com.jaidev.secondProject.user;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.springframework.stereotype.Component;

import jakarta.persistence.criteria.CriteriaBuilder.In;

@Component
public class UserDao {

	 static int count=1;
	
	static List<User> users=new ArrayList<>();
	
	static {
		users.add(new User(count++,"Jai","jai@mail.com","23231121"));
		users.add(new User(count++,"mohan","jai@mail.com","23231121"));
		users.add(new User(count++,"raj","jai@mail.com","23231121"));
	}
	
	public List<User> findAll()
	{
		return users;
	}
	public User findOne(Integer id)
	{	
		
//		for (User user : users) {
//			if (user.getid() == id) {
//				return user;
//			}
//		}
//		return null;
		
		
		return users.stream().filter(user -> user.getId()==id).findFirst().get();
		
	}
	public void save(User user) {
		// TODO Auto-generated method stub
		user.setUid(count++);
		users.add(user);
	}
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		users.removeIf(user->user.getId()==id);
	}
}
