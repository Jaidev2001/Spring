package com.jaidev.secondProject.user;
import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;
public class User {
Integer id;

@Valid @Size(min=2)
String uname;

@Email
String umail;
String unumber;



public User(int id, String uname, String umail, String unumber) {
	super();
	this.id = id;
	this.uname = uname;
	this.umail = umail;
	this.unumber = unumber;
}
public long getId() {
	return id;
}
public void setUid(int uid) {
	this.id = uid;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getUmail() {
	return umail;
}
public void setUmail(String umail) {
	this.umail = umail;
}
public String getUnumber() {
	return unumber;
}
public void setUnumber(String unumber) {
	this.unumber = unumber;
}
@Override
public String toString() {
	return "User [uid=" + id + ", uname=" + uname + ", umail=" + umail + ", unumber=" + unumber + "]";
}


	
}
