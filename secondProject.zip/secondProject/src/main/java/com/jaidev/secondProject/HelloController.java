package com.jaidev.secondProject;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

	@GetMapping("/hello")
	public String helloWorld()
	{
		return "HELLO WORLD from mapping";
	}
	
	@GetMapping("/hi")
	public MyBean helloWorldBean()
	{
		return new MyBean("Hello World from bean");
	}
	
}
