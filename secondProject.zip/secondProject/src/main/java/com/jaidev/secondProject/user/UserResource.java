package com.jaidev.secondProject.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserResource {

	@Autowired
	UserDao service=new UserDao();
	
	
	public UserResource(UserDao service) {
		super();
		this.service = service;
	}


	@GetMapping(path="/users")
	public List<User> getUsers()
	{
		
		return service.findAll();
	}
	@GetMapping(path="/users/{id}")
	public User getUsers(@PathVariable int id)
	{
		
		return service.findOne(id);
	}
	@PostMapping(path = "/users")
	public ResponseEntity<User> addUser(@RequestBody User user)
	{
		service.save(user);
		return ResponseEntity.created(null).build();
	}
	
	@DeleteMapping(path = "/users/{id}")
	public void deleteUser(@PathVariable int id)
	{
		service.deleteById(id);
	}
	
}
