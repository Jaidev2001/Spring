package com.telusko.springmvcboot;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.telusko.springmvcboot.model.user;

@Controller
public class HomeController
{
	@RequestMapping("/")
	public String home()
	{
		return "index";
	}
	@RequestMapping("add")
	public String add(@ModelAttribute("u1") user u)
	{
		
		return "view";
	}
	
}

