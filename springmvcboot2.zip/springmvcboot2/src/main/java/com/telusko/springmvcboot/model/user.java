package com.telusko.springmvcboot.model;

public class user {
int uid;
String uname;
String umail;
String unumber;
public int getUid() {
	return uid;
}
public void setUid(int uid) {
	this.uid = uid;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getUmail() {
	return umail;
}
public void setUmail(String umail) {
	this.umail = umail;
}
public String getUnumber() {
	return unumber;
}
public void setUnumber(String unumber) {
	this.unumber = unumber;
}
@Override
public String toString() {
	return "user [uid=" + uid + ", uname=" + uname + ", umail=" + umail + ", unumber=" + unumber + "]";
}


}
