package com.telusko.springmvcboot;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.telusko.springmvcboot.model.user;


import com.telusko.springmvcboot.model.user;
public interface userRepo extends JpaRepository<user, Integer>{
	
	List<user> findByUname(String uname);
	List<user> findByUmail(String umail);
	List<user> findByUnumber(String unumber);
	
	@Query("from user where uname= :uname")
	List<user> find(@Param("uname") String uname);//QUERY method
}
