package com.telusko.springmvcboot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.telusko.springmvcboot.model.user;
import com.telusko.springmvcboot.userRepo;

@Controller
public class HomeController {
	@Autowired
	userRepo repo;

	@RequestMapping("/")
	public String home() {
		return "index";
	}

	@PostMapping("add")
	public String add(@ModelAttribute("u1") user u) {
		repo.save(u);
		return "view";
	}
	@GetMapping(path = "getUsers",produces = {"application/json"}) //for xml file only and /json for json file
	//@GetMapping("getUsers")
	@ResponseBody
	public List<user> getUsers(Model m) {
		
		List<user> users= repo.findAll();
		return users;
	}

	@GetMapping("getUsers/{uid}")
	@ResponseBody
	public user getUser2(@PathVariable("uid") int uid)
	{
		user usr=repo.findById(uid).orElse(new user(0,"","",""));
		
		return usr; 
	}
	//@PostMappingpath = "getUsers",consumes= {"application/xml"}) //for xml file only and /json for json file
	@PostMapping("add2")
	@ResponseBody
	public user add2(@RequestBody user usr)
	{
		repo.save(usr);
		
		return usr;
	}
	
	@GetMapping("getUser")
	public String getUser(@RequestParam int uid, Model m) {

		m.addAttribute("result", repo.getOne(uid));

		return "show";

	}
	
	
	
	@GetMapping("getName")
	public String getName(@RequestParam String uname, Model m) {

		m.addAttribute("result", repo.find(uname));

		return "show";

	}
	@GetMapping("getMail")
	public String getMail(@RequestParam String umail, Model m) {

		m.addAttribute("result", repo.findByUmail(umail));

		return "show";

	}
	@GetMapping("getNumber")
	public String getNumber(@RequestParam String unumber, Model m) {

		m.addAttribute("result", repo.findByUnumber(unumber));

		return "show";

	}
	@PostMapping("delete")
	public String delete(@ModelAttribute("u1") user u) {
		repo.delete(u);
		return "view";
	}
	

}
