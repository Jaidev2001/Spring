package com.telusko.springmvcboot.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class user {
	
	@Id
	int uid;
	String uname;
	String umail;
	String unumber;
	
	public user()
	{
		
	}

	public user(int uid, String uname, String umail, String unumber) {
		super();
		this.uid = uid;
		this.uname = uname;
		this.umail = umail;
		this.unumber = unumber;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUmail() {
		return umail;
	}

	public void setUmail(String umail) {
		this.umail = umail;
	}

	public String getUnumber() {
		return unumber;
	}

	public void setUnumber(String unumber) {
		this.unumber = unumber;
	}

	@Override
	public String toString() {
		return "user [uid=" + uid + ", uname=" + uname + ", umail=" + umail + ", unumber=" + unumber + "]";
	}

}
